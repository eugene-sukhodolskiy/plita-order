# has_child

```php
has_child ( ) : bool
```

Returns true if the current node has one or more child nodes.